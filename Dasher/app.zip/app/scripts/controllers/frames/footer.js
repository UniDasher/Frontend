angular
	.module('btApp')
	.controller('FooterController', function($scope, $injector) {

	});